from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from plyer import notification
import time

class Notifier(QWidget):
    def __init__(self):
        super().__init__()
        self.setStyleSheet("\n"
                                 "background-color: rgb(131, 142, 162);")
        self.setWindowTitle("Notifier")
        self.setFixedSize(500,300)

        self.image_label = QLabel(self)
        self.image = QPixmap("notify-label.png")
        self.image_label.setPixmap(self.image)

        # Label - Title
        self.title_label = QLabel(self)
        self.title_label.setText("Title to Notify")
        self.title_label.setFont(QFont("poppins", 10)).

        self.title_label.move(12, 70)

        # ENTRY - Title
        self.title = QLineEdit(self)
        self.title.setFont(QFont("poppins", 13))
        self.title.resize(280, 30)
        self.title.move(123, 65)

        # Label - Message
        self.msg_label = QLabel(self)
        self.msg_label.setText("Display Message")
        self.msg_label.setFont(QFont("poppins", 10))
        self.msg_label.move(12, 120)

        # ENTRY - Message
        self.msg = QLineEdit(self)
        self.msg.setFont(QFont("poppins", 13))
        self.msg.resize(280, 30)
        self.msg.move(140, 115)

        # Label - Time
        self.time_label = QLabel(self)
        self.time_label.setText("Set Time")
        self.time_label.setFont(QFont("poppins", 10))
        self.time_label.move(12, 175)

        # ENTRY - Time
        self.time1 = QLineEdit(self)
        self.time1.setFont(QFont("poppins", 13))
        self.time1.resize(50, 30)
        self.time1.move(100, 173)

        # Label - min
        self.time_min_label = QLabel(self)
        self.time_min_label.setText("min")
        self.time_min_label.setFont(QFont("poppins", 10))
        self.time_min_label.move(155, 180)

        # Button
        self.but = QPushButton(self)
        self.but.setText("SET NOTIFICATION")
        self.but.setFont(QFont("poppins", 10, QFont.Bold))
        self.but.setStyleSheet("color:#ffffff; background-color:#528DFF;")
        self.but.resize(200, 40)
        self.but.move(150, 230)
        self.but.clicked.connect(self.get_details)

        self.show()

    # get details
    def get_details(self):
        get_title = self.title.text()
        get_msg = self.msg.text()
        get_time = self.time1.text()

        if get_title == "" or get_msg == "" or get_time == "":
            QMessageBox.critical(self, "Alert", "All fields are required!")
        else:
            int_time = int(float(get_time))
            min_to_sec = int_time * 60
            QMessageBox.information(self, "Notifier Set", "Set notification ?")
            self.close()
            time.sleep(min_to_sec)

            notification.notify(
                title=get_title,
                message=get_msg,
                app_name="Notifier",
                toast=True,
                timeout=10,
            )

if __name__ == "__main__":
    app = QApplication([])
    window = Notifier()
    app.exec_()
