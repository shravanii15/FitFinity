from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_timer3(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        self.init_ui()
        self.timer = QtCore.QTimer(self)
        self.timer.timeout.connect(self.update_time)
        self.elapsed = 0

    def init_ui(self):
        self.setWindowTitle('timer3')
        self.setStyleSheet("background-color: rgb(51, 48, 48);\n"
                                "background-color: rgb(44, 49, 60);")
        self.setGeometry(100, 100, 600, 600)
        self.label = QtWidgets.QLabel('00:00:00', self)
        self.label.setGeometry(110, 100, 370, 200)
        self.start_button = QtWidgets.QPushButton('Start', self)
        self.start_button.setGeometry(120, 300, 150, 60)
        self.start_button.setStyleSheet("background-color:#FF63D1\n"
                                        "border-radius-20px;\n""font-size:25px;")
        self.start_button.clicked.connect(self.start_stopwatch)
        self.reset_button = QtWidgets.QPushButton('Reset', self)
        self.reset_button.setGeometry(300, 300, 150, 60)
        self.reset_button.clicked.connect(self.reset_stopwatch)
        self.reset_button.setStyleSheet("background-color:#FF63D1\n"
                                      "border-radius-20px;\n""font-size:25px;")

        self.show()

    def start_stopwatch(self):
        if not self.timer.isActive():
            self.timer.start(10)
            self.start_button.setText('Stop')
        else:
            self.timer.stop()
            self.start_button.setText('Start')

    def reset_stopwatch(self):
        self.timer.stop()
        self.start_button.setText('Start')
        self.elapsed = 0
        self.update_time()

    def update_time(self):
        self.elapsed += 10
        milliseconds = int((self.elapsed / 10) % 100)
        seconds = int((self.elapsed / 1000) % 60)
        minutes = int((self.elapsed / (1000 * 60)) % 60)
        hours = int((self.elapsed / (1000 * 60 * 60)) % 24)
        time_str = '{:02d}:{:02d}:{:02d}.{:02d}'.format(hours, minutes, seconds, milliseconds)
        self.label.setText(time_str)
        self.label.setFont(QtGui.QFont('Times New Roman', 60, QtGui.QFont.Bold))
        self.label.setStyleSheet("QLabel { color: #838ea2; }")


if __name__ == '__main__':
    app = QtWidgets.QApplication([])
    stopwatch = Ui_timer3()
    app.exec_()
