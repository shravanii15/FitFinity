import sys
from PyQt5.QtWidgets import QApplication, QWidget, QLabel, QDoubleSpinBox, QPushButton, QVBoxLayout

class BMICalculator(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.setWindowTitle('BMI Calculator')
        self.resize(524,357)
        weight_label = QLabel('Weight (kg):')
        self.weight_spinbox = QDoubleSpinBox()
        self.weight_spinbox.setRange(0.0, 500.0)
        self.weight_spinbox.setValue(70.0)

        height_label = QLabel('Height (cm):')
        self.height_spinbox = QDoubleSpinBox()
        self.height_spinbox.setRange(0.0, 300.0)
        self.height_spinbox.setValue(170.0)

        self.calculate_button = QPushButton('Calculate')
        self.calculate_button.clicked.connect(self.calculateBMI)

        self.bmi_label = QLabel('BMI:')

        vbox = QVBoxLayout()
        vbox.addWidget(weight_label)
        vbox.addWidget(self.weight_spinbox)
        vbox.addWidget(height_label)
        vbox.addWidget(self.height_spinbox)
        vbox.addWidget(self.calculate_button)
        vbox.addWidget(self.bmi_label)

        self.setLayout(vbox)

    def calculateBMI(self):
        weight = self.weight_spinbox.value()
        height = self.height_spinbox.value() / 100.0 # convert cm to m
        bmi = weight / (height * height)
        self.bmi_label.setText(f'BMI: {bmi:.2f}')

if __name__ == '__main__':
    app = QApplication(sys.argv)
    bmi_calculator = BMICalculator()
    bmi_calculator.show()
    sys.exit(app.exec_())
